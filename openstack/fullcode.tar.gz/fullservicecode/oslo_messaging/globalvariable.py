# SYQ
# To implement global variables that can help differentiate service daemon
# and forked instances
import os
import threading
import eventlet

def init(serviceObject):
    global isDaemon
    isDaemon = True
    global serviceObj 
    serviceObj = serviceObject
    global servicePID
    servicePID = os.getpid()
    global callLock
    callLock = eventlet.semaphore.Semaphore()

def init_transport(transportObj):
    global transport
    transport = transportObj
