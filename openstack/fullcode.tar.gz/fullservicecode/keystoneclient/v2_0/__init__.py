from keystoneclient.v2_0.client import Client  # noqa


__all__ = [
    'client',
]
